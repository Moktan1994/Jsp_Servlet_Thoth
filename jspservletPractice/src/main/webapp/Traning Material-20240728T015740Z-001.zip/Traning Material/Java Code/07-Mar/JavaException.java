package exceptions;

public class JavaException {

	public static void main(String[] args) {
		int num1 = 20;
		int num2 = 0;
		
		int result = division(num1, num2);
		
		System.out.println("Result will be " + result);
		
		int totalSum = sum(num1, num2);
		
		System.out.println("Total sum "+ totalSum);

	}
	
	public static int division(int number1, int number2) {
		try {
			return number1 / number2;	
		}catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		
		
	}
	
	public static int sum(int number1, int number2) {
		return number1 + number2;
	}
	
	public int sub(int number1, int number2) {
		return number1 - number2;
	}

}
