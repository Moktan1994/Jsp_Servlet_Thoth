package exceptions;

public class ArrayException {
	
	static String s1 = "Vikas";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] array = {"Apple", "Banana", "Oranges"};
		
		
		try {
			
			System.out.println("Value of array 2 " + array[2]);
			System.out.println("Division Value " + 10/2);
			
			System.out.println("Length "+ s1.length());
			
		}catch (ArrayIndexOutOfBoundsException ai) {
			System.out.println("Something went wrong in Array!");
		}catch (ArithmeticException ae) {
			System.out.println("Something went wrong while dividing!");
		}catch (Exception e) {
			System.out.println("Its something big wrong");
			e.printStackTrace();
		}
		
		//System.out.println("Value of array 1 " + array[1]);

	}

}
