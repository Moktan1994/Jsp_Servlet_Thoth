package exceptions;

public class ArthmeticException {

	public static void main(String[] args) {
		try {
		int num1 = 20;
		int num2 = 5;
		
		if(num2 <= 0) {
			System.out.println("you can't divide by zero or less than 0");
		}else {
			System.out.println(num1/num2);
		}
		
		//num2 = 0;
		
		System.out.println(num1/num2);
		
		JavaException je = null;
		
		int result = je.sub(50, 10);
		
		System.out.println("Result " + result);
		
		}catch (Exception e) {
			System.out.println("Something went wrong");
			e.printStackTrace();
		}

	}

}
