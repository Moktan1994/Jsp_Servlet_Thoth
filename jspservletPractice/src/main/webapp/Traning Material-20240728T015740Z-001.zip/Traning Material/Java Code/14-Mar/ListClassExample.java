package collection;

import java.util.ArrayList;

public class ListClassExample {

	public static void main(String[] args) {
		ArrayList<String> studentName = new ArrayList<String>();
		ArrayList<Integer> studentRollNo = new ArrayList<Integer>();
		
		studentName.add("MO");
		studentName.add("Vikas");
		
		studentRollNo.add(1000);
		studentRollNo.add(1001);
		
		// Name = MO and Roll No = 1000
		
		System.out.println("Name- " + studentName.get(0) + " Roll No- " + studentRollNo.get(0));

	}

}
