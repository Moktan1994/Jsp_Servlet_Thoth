package collection;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class ArrayList {

	public static void main(String[] args) {
		String[] student = {"MO", "MO", "Sharada"};
		
		String student1 = "MO";
		
		System.out.println(student1);
		
		student1 = student1 + "Class";
		
		System.out.println(student1);
		
		String[] student3 = {"MO", "Anjana", "Sharada", "Vikas"};
		
		System.out.println(student3[3]);
		
		//Benifit of Arraylist
		
		//List<String> linkList = new LinkedList<String>();
		
		List<String> studentList = new java.util.ArrayList<String>();
		studentList.add("MO");
		studentList.add("Anjana");
		studentList.add("Sharada");
		studentList.add("Vikas");
		
		System.out.println(studentList.size());
		
		System.out.println(studentList.get(3));
		
		//Method 1 = add
		//Method 2 = get
		
		System.out.println("1" + studentList);
		
		studentList.add("Bikesh");
		
		System.out.println("2" + studentList);
		
		studentList.remove(4);
		
		System.out.println("3" + studentList);
		
		studentList.set(3, "Bikesh");
		
		System.out.println("4" + studentList);
		
		studentList.remove(0);
		System.out.println("5" + studentList);
		studentList.remove(1);
		//System.out.println(studentList);
		studentList.remove(1);
		System.out.println("6" + studentList);
		
		System.out.println(studentList.get(0));
		
		studentList.add("MO");
		studentList.add("Anjana");
		studentList.add("Sharada");
		studentList.add("Vikas");
		
		System.out.println("7" + studentList);
		
		studentList.clear();
		
		System.out.println("8" + studentList);
		
		studentList.add("MO");
		studentList.add("Anjana");
		studentList.add("Sharada");
		studentList.add("Vikas");
		studentList.add("Apil");
		studentList.add("Maryam");
		
		System.out.println("9" + studentList);
		
		//How to print the object
		
		for(int i = 0; i < studentList.size(); i++) {
			System.out.println("Position " + i + " of " + studentList.get(i));
			
			if(studentList.get(i).equalsIgnoreCase("SHArada")) 
				studentList.remove(i);
			else
				System.out.println("Position " + i + " of " + studentList.get(i));
		}
		
		System.out.println("9" + studentList);
		
		Collections.sort(studentList);
		
		System.out.println("10" + studentList);

	}

}
