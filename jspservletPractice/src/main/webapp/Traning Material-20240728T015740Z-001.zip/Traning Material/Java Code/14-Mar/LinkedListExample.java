package collection;

import java.util.ArrayList;
import java.util.LinkedList;

public class LinkedListExample {

	public static void main(String[] args) {
		
		LinkedList<String> linkList = new LinkedList<String>();
		
		linkList.add("MO");
		linkList.add("Vikas");
		
		System.out.println(linkList);
		
		linkList.addFirst("Sharada");
		linkList.addLast("Bikesh");
		
		System.out.println(linkList);
		
		System.out.println("-------------------");
		
		ArrayList<String> arrayList = new ArrayList<String>();
		
		arrayList.add("MO");
		arrayList.add("Vikas");
		
		System.out.println(arrayList);
		
		arrayList.add(0, "Sharada");
		arrayList.add("Bikesh");
		
		System.out.println(arrayList);

	}

}
