package collection;

import java.util.ArrayList;
import java.util.Collections;

public class ListSorting {

	public static void main(String[] args) {
		ArrayList<Integer> intList = new ArrayList<Integer>();
		
		intList.add(500);
		intList.add(500);
		intList.add(350);
		intList.add(200);
		intList.add(440);
		intList.add(760);
		intList.add(1000);
		intList.add(600);
		
		System.out.println(intList);
		
		Integer totalSum = intList.get(0) + intList.get(1) + 
				intList.get(2) + intList.get(3) + intList.get(4) +
				intList.get(5) + intList.get(6)+ intList.get(7);
		Integer totalsum2 = 0;
		
		System.out.println("Total Sum " + totalSum);
		
		for(int i =0;i<intList.size();i++)
		{
			totalsum2 = totalsum2 + intList.get(i);
		}
		
		System.out.println("Total Sum 2 " + totalsum2);
		
		Collections.sort(intList);
		
		System.out.println(intList);
		

	}

}
