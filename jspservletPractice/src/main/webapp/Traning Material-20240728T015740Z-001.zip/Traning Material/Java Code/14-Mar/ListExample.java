package collection;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListExample {

	public static void main(String[] args) {
		String stringObject = new String("Apple");
		
		System.out.println(stringObject);
		
		ArrayList<String> stringList = new ArrayList<String>();
		
		List<String> stringList1;
		
		int input = 1;
		
		if(input == 1)
			stringList1 = new LinkedList();
		else
			stringList1 = new ArrayList<String>();
	}

}
