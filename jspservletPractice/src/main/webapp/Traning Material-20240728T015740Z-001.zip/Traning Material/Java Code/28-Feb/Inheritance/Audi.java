package oops;

public class Audi {

	public static void main(String[] args) {
		FinalCar car = new FinalCar();
		
		car.myHorn();
		
		car.camera();

	}

}
