package oops;

public class BMW extends Car{

	public static void main(String[] args) {
		
		BMW bmw = new BMW();
		bmw.carBrake();
		
		bmw.carCamera();
		
		Car car = new Car();
		
		car.carBrake();

	}

}
