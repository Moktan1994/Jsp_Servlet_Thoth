package oops;

public class Car extends Inheritance {
	
	public static void main(String[] args) {
		Car car = new Car();
		
		//car.carBrake();
		
		car.horn();
		
		
		car.hornSound();
	}
	
	public void carCamera() {
		System.out.println("Car have a 360 degree view camera");
	}
	
	public void hornSound() {
		System.out.println("Horn is Blink Blink");
	}

}
