package oops;

final class FinalCar {
	
	public void myHorn() {
		System.out.println("Good Honking");
	}
	
	public void camera() {
		System.out.println("Mine Camera");
	}

}
