package oops;

public class OtherClassRefrence extends Inheritance {

	public static void main(String[] args) {
		
		Inheritance in = new Inheritance();
		
		in.horn();
		in.carBrake();
		in.hornSound();
		
		Inheritance in1 = new Car();
		
		in1.hornSound();
		
		Car c1 = new Car();
		c1.carCamera();

	}

}
