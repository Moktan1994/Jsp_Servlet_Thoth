package oops;

public class FirstClass {
	
	public static int weight;
	public static String name;

	
	public FirstClass() {
		weight = 50;
		name = "Vikas";
	}
	
	public static void main(String[] args) {
		FirstClass firstClass = new FirstClass();
		
		System.out.println(firstClass.weight);
	}
	
	public void todosum()
	{
		FirstClass firstClass = new FirstClass();
		
		System.out.println(firstClass.sum(5,5));
	}
	
	void todosub()
	{
		FirstClass firstClass = new FirstClass();
		
		System.out.println(firstClass.sub(10,5));
	}
	
	public int sum (int number1, int number2) {
		return number1 + number2;
	}
	
	public int sub (int number1, int number2) {
		return number1 - number2;
	}

}
