package oops;

public class Constructor {
	
	static int weight;
	static String name;
	
	Constructor(){
		weight = 50;
		name = "Vikas";
	}
	
	Constructor(int value, String nameValue){
		weight = value;
		name = nameValue;
	}

	public static void main(String[] args) {
		System.out.println(weight);
		System.out.println(name);
		
		Constructor c1 = new Constructor();
		
		System.out.println(weight);
		System.out.println(name);
		
		Constructor c2 = new Constructor(10, "Mo");
		
		System.out.println(weight);
		System.out.println(name);

	}

}
