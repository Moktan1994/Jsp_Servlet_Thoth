package oops;

public class SubNumbers {
	
	public static void main(String[] args) {
		
		FirstClass f1 = new FirstClass();
		
		f1.todosub();
	}

}
