package oops;

import classes.TestClass;

public class SumNumbers {

	
	
	public static void main(String[] args) {
		
		
		
		FirstClass f1 = new FirstClass();
		
		System.out.println(f1.weight);
		
		//f1.todosum();
		
		f1.weight = 25;
		
		System.out.println(f1.weight);
		
		TestClass testClass = new TestClass();
		
		//System.out.println(testClass.valueoftest);
		
		
		

	}

}
