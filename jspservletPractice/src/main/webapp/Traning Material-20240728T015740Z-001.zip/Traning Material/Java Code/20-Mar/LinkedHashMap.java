package collection;

import java.util.HashMap;

public class LinkedHashMap {

	public static void main(String[] args) {
		
		HashMap<String, String> hashExample = new HashMap<String, String>();
		
		hashExample.put("VK1001", "Vikas");
		hashExample.put("MO1002", "MO");
		hashExample.put("MR1004", "Maryam");
		hashExample.put("BK2001", "Bikesh");
		hashExample.put("AP1010", "Apil");
		
		for (String j : hashExample.keySet()) {
			System.out.println(j);
		}
		
		System.out.println("Linked HashMap__________");
		
		java.util.LinkedHashMap<String, String> linkedHashMap = new java.util.LinkedHashMap<String, String>();
		
		linkedHashMap.put("VK1001", "Vikas");
		linkedHashMap.put("MO1002", "MO");
		linkedHashMap.put("MR1004", "Maryam");
		linkedHashMap.put("BK2001", "Bikesh");
		linkedHashMap.put("AP1010", "Apil");
		linkedHashMap.put("VK1001", "India");
		
		for (String j : linkedHashMap.keySet()) {
			System.out.println(j);
		}

	}

}
