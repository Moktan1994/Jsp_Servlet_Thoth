package collection;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class TreeMapExample {

	public static void main(String[] args) {
		
		Map<String, String> hashMap = new HashMap<String, String>();
		
		hashMap.put("V", "Vikas");
		hashMap.put("M", "MO");
		hashMap.put("A", "Apil");
		
		System.out.println("Printing HashMap Keys");
		for (String j : hashMap.keySet()) {
			System.out.println(j);
		}
		
		System.out.println("-------------------------------");
		
		Map<String, String> linkedHashMap = new LinkedHashMap();
		
		linkedHashMap.put("V", "Vikas");
		linkedHashMap.put("M", "MO");
		linkedHashMap.put("A", "Apil");
		
		System.out.println("Printing HashMap Keys");
		for (String j : linkedHashMap.keySet()) {
			System.out.println(j);
		}
		
		System.out.println("-------------------------------");
		
		Map<String, String> treeMap = new TreeMap<String, String>();
		
		treeMap.put("10", "Vikas");
		treeMap.put("2", "MO");
		treeMap.put("1", "Apil");
		
		for (String j : treeMap.keySet()) {
			System.out.println(j);
		}
		System.out.println("----------------------");
		Map<Integer, String> treeMap1 = new TreeMap<Integer, String>();
		
		treeMap1.put(10, "Vikas");
		treeMap1.put(2, "MO");
		treeMap1.put(1, "Apil");
		
		for (Integer j : treeMap1.keySet()) {
			System.out.println(j);
		}

	}
}
