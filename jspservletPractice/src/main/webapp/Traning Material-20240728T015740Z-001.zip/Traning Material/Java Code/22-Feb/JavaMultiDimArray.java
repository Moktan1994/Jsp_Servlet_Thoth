package training;

public class JavaMultiDimArray {

	public static void main(String[] args) {
		
		String[][] students = {{"A","B","C","D"},{"E","F","G","H"},{"MO","Bikesh"}};
		
		System.out.println(students[2][1]);
		
		students[2][1] = "Vikas";
		
		System.out.println(students[2][1]);

	}

}
