package training;

public class JavaArray {

	public static void main(String[] args) {
		String[] students = {"Apil","Mariyam","MO","Satish"};
		
		//System.out.println(students[0]);
		
		students[0] = "Sharada";
		
		System.out.println(students[0]);
		
		//System.out.println(students.length);
		
		//To print the values of loop
		
		for(int num = 0; num < students.length; num++) {
			
			if(num == 3)
				System.out.println(students[num]);
		}

	}

}
