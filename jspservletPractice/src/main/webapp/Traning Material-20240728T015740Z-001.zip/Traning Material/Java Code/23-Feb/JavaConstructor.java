package classes;

public class JavaConstructor {
	
	int number;
	
	public JavaConstructor()
	{
		number = 10;
	}

	public static void main(String[] args) {
		
		JavaConstructor javaConstructor = new JavaConstructor();
		
		System.out.println(javaConstructor.number);
		
		//javaConstructor.number = 10; 
		
		//System.out.println(javaConstructor.number);

	}

}
