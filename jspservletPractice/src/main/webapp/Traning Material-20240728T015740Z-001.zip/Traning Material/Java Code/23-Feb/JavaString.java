package training;

public class JavaString {

	public static void main(String[] args) {
		String data = "My Name Is Vikas";
		System.out.println(data.indexOf("Vikas"));
		
		String string1 = "Apple ";
		String string2 = "is a fruit";
		
		System.out.println(string1 + string2);
		
		System.out.println(2 + 3);
		
		System.out.println("2" + "3");
		
		System.out.println("2" + 3);
		
		System.out.println(data);
		
		data = data.replace("Vikas", "MO");
		
		System.out.println(data);
		
		String data1 = "Apple is a good Fruit. We need to eat Apple everyday";
		
		System.out.println(data1);
		
		data1 = data1.replaceFirst("Apple", "Banana");
		
		//data1 = data1.replace("Apple", "Banana");
		
		System.out.println(data1);
		
		String data2 = "My Name is \"Vikas\" ";
		
		System.out.println(data2);
	}

}
