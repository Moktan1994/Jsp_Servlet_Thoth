package classes;

public class JavaOtherClass {
	
	int intValue = 50;

	public static void main(String[] args) {
		
		JavaOtherClass otherClass = new JavaOtherClass();
		System.out.println(otherClass.intValue); 
		
	}

}
