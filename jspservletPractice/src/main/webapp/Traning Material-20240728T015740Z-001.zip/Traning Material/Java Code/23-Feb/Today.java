package training;

public class Today {

	int classInt = 10;
	final String classString = "Java Class";
	
	public static void main(String[] args) {
		
		int methodInt = 20;
		
		Today javaClass = new Today();
		
		System.out.println(methodInt);
		
		System.out.println(javaClass.classInt);
		
		Today javaClass1 = new Today();
		
		System.out.println(javaClass1.classString);
	}
	
	public int sum (int num1, int num2)
	{
		return num1+num2;
	}

}
