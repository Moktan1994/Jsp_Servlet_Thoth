package training;

import classes.JavaOtherClass;

public class JavaClassSecond {

	public static void main(String[] args) {
		Today javaClass = new Today();
		
		System.out.println(javaClass.classString);
		
		JavaOtherClass otherClass = new JavaOtherClass();
		//System.out.println(otherClass.intValue);
		
		int sum = javaClass.sum(35, 70);
		
		//System.out.println(javaClass.sum());
		
		System.out.println(sum);
		
		//javaClass.classString = "Hello OOps";
		
		System.out.println(javaClass.classString);

	}

}
