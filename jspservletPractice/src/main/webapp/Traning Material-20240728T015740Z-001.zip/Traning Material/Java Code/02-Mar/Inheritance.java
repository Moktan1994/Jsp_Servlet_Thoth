package oops;

class Inheritance {
	
	String carBrand = "Ford";
	
	public void carBrake() {
		System.out.println("Brake Applied");
	}
	
	public void horn() {
		System.out.println("Honk Honk");
	}
	
	private void carColor() {
		System.out.println("color should be RED");
	}
	
	public void hornSound() {
		System.out.println("Horn is Blow Blow");
	}
	
	public void hornSound(String voice) {
		System.out.println("Horn is Blow Blow");
	}

}
