package oops;

public class Person {

	private int age = 25;
	private String name = "MO";
	private String dateOfBirth = "21-Jun-19880";

	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		
		if(age == 30) {
			this.age = age;
		}
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

}
