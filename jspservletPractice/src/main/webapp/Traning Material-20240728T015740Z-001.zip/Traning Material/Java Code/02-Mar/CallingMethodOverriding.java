package oops;

public class CallingMethodOverriding extends MethodOverriding {

	public static void main(String[] args) {
		
		CallingMethodOverriding cmo = new CallingMethodOverriding();
		
		//System.out.println(cmo.yourCity());
		
		//cmo.hondaBike();
		
		cmo.runShop();

	}
	
	public void hondaBike() {
		System.out.println("This bike belongs to me");
		System.out.println("This is RED in color and very fast");
	}
	
	final public void runShop() {
		System.out.println("Final Second Shop");
	}

}
