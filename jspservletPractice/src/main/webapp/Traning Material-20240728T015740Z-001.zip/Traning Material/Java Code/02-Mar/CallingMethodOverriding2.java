package oops;

public class CallingMethodOverriding2 extends CallingMethodOverriding{

	public static void main(String[] args) {
		CallingMethodOverriding2 cmo2 = new CallingMethodOverriding2();
		
		cmo2.runShop();
		
		cmo2.hondaBike();
		
		MethodOverriding mo = new MethodOverriding();
		
		//mo.runShop();

	}

}
