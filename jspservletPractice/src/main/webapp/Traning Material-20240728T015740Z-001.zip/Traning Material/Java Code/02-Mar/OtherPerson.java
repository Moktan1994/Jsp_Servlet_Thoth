package oops;

public class OtherPerson {

	public static void main(String[] args) {
		Person p = new Person();
		
		
		//System.out.println(p.age);
		
		//p.age = 40;
		
		//System.out.println(p.age);
		
		//System.out.println(p.getAge());
		
		//System.out.println(p.getAge());
		
		//System.out.println(p.getAge());
		
		//System.out.println(p.getName());
		
	}
	
	public void showYourAge()
	{
		Person p = new Person();
		p.setAge(30);
		
		System.out.println(p.getAge());
		
	}

}
