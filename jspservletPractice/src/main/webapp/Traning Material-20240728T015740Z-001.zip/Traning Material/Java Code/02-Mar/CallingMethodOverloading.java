package oops;

public class CallingMethodOverloading {

	public static void main(String[] args) {
		MethodOverloading mo = new MethodOverloading();
		
		System.out.println(mo.addNumbers(10, 20));
		
		System.out.println(mo.addNumbers(10, 20, 30));
		
		System.out.println(mo.addNumbers(10, 20, 30, 40));

	}

}
