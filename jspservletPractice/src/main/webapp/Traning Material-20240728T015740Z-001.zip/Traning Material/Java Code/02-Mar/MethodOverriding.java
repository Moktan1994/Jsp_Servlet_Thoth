package oops;

public class MethodOverriding {
	
	public void hondaBike() {
		System.out.println("This bike is belongs to your father");
	}
	
	public String yourCity() {
		return "Delhi";
	}
	
	public void runShop() {
		System.out.println("First Shop");
	}

}
