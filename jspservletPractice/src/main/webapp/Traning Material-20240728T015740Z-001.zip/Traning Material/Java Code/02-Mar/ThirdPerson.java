package oops;

public class ThirdPerson extends OtherPerson {

	public static void main(String[] args) {
		ThirdPerson tp = new ThirdPerson();
		
		tp.showYourAge();

	}

}
