package strings;

public class StringUsage {
	
	static String classString = "ClassLevel";

	public static void main(String[] args) {
		String name = new String("MO");
		String section = "5";
		
		String name1 = new String("Vikas");
		String section1 = "6";
		
		String name2 = new String("Bikesh");
		String section2 = "7";
		
		System.out.println("1 " + name);
		
		System.out.println("2 " + name1);
		
		System.out.println("3 " + name+name1);
		
		name = "MOSAM";
		
		String newString = classString;
		
		classString = "ClassMethod";
		
		int i = 5;
		
		System.out.println("Value of i " + i);
		
		i = i+10;
		
		System.out.println("Value of i " + i);
		

	}

}
