package training;

public class MethodOverloading {

	public static void main(String[] args) {
		
		float sum = sum(34.45f, 56.56f);
		System.out.println(sum);

	}
	
	public static int sum(int number1, int number2)
	{
		int totalSum = number1 + number2;
		
		totalSum = 0;
		
		return totalSum;
	}
	
	public static float sum(float number1, float number2)
	{
		//totalSum = 0;
		
		return number1 + number2;
	}

}
