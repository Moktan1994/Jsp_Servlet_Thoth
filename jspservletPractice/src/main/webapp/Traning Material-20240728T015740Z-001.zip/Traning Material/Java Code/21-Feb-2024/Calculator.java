package training;

public class Calculator {

	public static void main(String[] args) {
		
		System.out.println("Hello Vikas");
		
		int actionValue = 1;
		int result =0;
		
		if(actionValue == 1) {
			result = sum(25, 30, 25);
			
			System.out.println("Do you want to continue .. Yes or No");
			String confirm = "yes";
			if(confirm == "Yes"){
				menu();
			}
		}
		
		if(actionValue == 2) {
			result = substraction(50, 30);
		}
		
		if(actionValue == 3) {
			result = multiply(25, 30);
		}
		
		System.out.println("The result is " + result);
		
		if(actionValue == 5) {
			menu();
		}
	}
	
	public static void menu()
	{
		System.out.println("1. Sum of two number");
		System.out.println("2. Sub");
		System.out.println("3. Multiply");
		System.out.println("4. Division");
		System.out.println("5. Want another option");
		System.out.println("6. Exit");
	}
	
	public static int sum(int number1, int number2, int number3 )
	{
		int totalSum = number1 + number2 + number3;
		
		if(totalSum > 90)
			return totalSum;
		else
			return 0;
	}
	
	public static int substraction(int number1, int number2 )
	{
		return 0;
	}
	
	public static int multiply(int number1, int number2 )
	{
		return number1 * number2;
	}
	
	public static int divide(int number1, int number2 )
	{
		return number1 % number2;
	}

}
