package exceptions;

public class ThrowException {

	public static void main(String[] args) {
		String[] array = {"Apple", "Banana", "Oranges"};
		int age = 15;
		try 
		{
			//System.out.println(10/0);
			
			if(array[0] == "Banana") {
				throw new ArithmeticException("Choice is wrong");
			}
			
			if(age < 18)
			{
				throw new Exception("Age is not right");
			}
		}catch (ArithmeticException e) {
			System.out.println("It should be the Mango");
			e.printStackTrace();
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("ArrayIndexOutOfBoundsException Exception");
		}catch (Exception e) {
			System.out.println("Age should be 18");
			e.printStackTrace();
		}

	}

}
