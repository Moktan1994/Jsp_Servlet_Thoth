package exceptions;

public class Finally {
	
	public static void main(String[] args) {
		String[] array = {"Apple", "Banana", "Oranges"};
		
		try {
			
			displayName();
			
			int num = 10;
			int result = num/0;
			
			System.out.println(array[3]);
			
			System.out.println(result);
			
			//displayName();
		}catch (ArithmeticException e) {
			System.out.println("Something went wrong");
			e.printStackTrace();
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Something went wrong");
		}catch (Exception e) {
			System.out.println("Something went wrong");
		}//finally {
			//try {
			//System.out.println("Do you want to continue");
			//String input = "Yes";
			//if(input == "Yes")
				//displayName();
			//}catch (Exception e) {
				//System.out.println("There should be a problem");
			//}
		//}
	}
	
	public static void displayName() {
		System.out.println("Menu");
		System.out.println("1. Add");
		System.out.println("2. Sub");
	}

}
