package strings;

public class JavaString2 {

	public static void main(String[] args) {
		String s1 = "Java";
		String s2 = "Java";
		String s3 = s1 + s2;
		
		String s4 = s3;
		
		
		
		String s5 = new String("Python");
		String s6 = new String("Python");
		String s7 = new String("Java");
		String s8 = s1.intern();
		

	}

}
