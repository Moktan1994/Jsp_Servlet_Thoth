package strings;

public class JavaString {

	public static void main(String[] args) {
		
		String s1 = "Java"; // with the help of String literals
		
		String s2 = new String("Java"); // with the help of new keyword
		
		String s3 = "Java";
		
		System.out.println("s1 " + s1);
		System.out.println("s2 " + s2);
		
		//System.out.println(s1 == s2);
		
		System.out.println(s1 == s3);
		
		System.out.println(s1 == s2.intern());
		
		
		

	}

}
