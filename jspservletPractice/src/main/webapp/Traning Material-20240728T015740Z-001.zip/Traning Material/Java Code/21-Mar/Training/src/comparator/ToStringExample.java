package comparator;

import java.util.ArrayList;

public class ToStringExample {

	public static void main(String[] args) {
		
		Integer intValue = 100;
		Double flotValue = 200.00;
		
		ArrayList<String> strArray = new ArrayList<String>();
		
		strArray.add(intValue.toString());
		strArray.add(flotValue.toString());
		strArray.add("Vikas");
		
		System.out.println(strArray);

	}

}
