package training;

public class JavaLoops {

	public static void main(String[] args) {
//While loop
		String name = "Sam";
		
		while(name == "Vikas") {
			//System.out.println("Hello Vikas");
			break;
		}

// for loop
		for(int number = 1;number <=10;number++) {
			//System.out.println(number);
		}
		
//Nested Loop
		
		//11111
		//22222
		//33333
		//44444
		//55555
		//5
		//4
		//3
		//2
		//1
		
		/*for(int number = 1;number <=5;number++) {
			for(int repeatnum = 1; repeatnum <=5;repeatnum++) {
			System.out.print(repeatnum);
			}
			System.out.println();
		}*/
		
		for(int number3 = 1;number3 <=5;number3++) {
			System.out.println(number3);
		}
		
		for(int number2 = 5;number2 >=1;number2--) {
			System.out.println(number2);
		}
		
	}

}
