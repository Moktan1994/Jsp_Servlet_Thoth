package classes;

import oops.FirstClass;

public class TestClass {
	
	public int valueoftest = 100;

	public static void main(String[] args) {
		FirstClass f1 = new FirstClass();
		
		// TODO Auto-generated method stub

	}

}
