package strings;

public class StringMethods {

	public static void main(String[] args) {
		String s1 = new String("Java");
		
		String s2 = "VikasMO";
		
		String s3 = "Python";
		
		String s4 = "Test M and Use M Close";
		
		int s1Length = s1.length();
		
		System.out.println(s1 + s2);
		
		System.out.println(s2 + s1.intern());
		
		System.out.println(s1Length);
		System.out.println(s2.length());
		System.out.println(s2.charAt(5));
		System.out.println(s2.substring(5));
		System.out.println(s2.substring(2,5));
		System.out.println(s1.concat("VikasMO"));
		System.out.println(s2 + s3);
		
		System.out.println(s4.indexOf("M"));
		
		System.out.println(s4.indexOf("M", 6));
		
		System.out.println(s4.lastIndexOf("e"));
		
		System.out.println(s4.indexOf("e"));
		
		
		String firstString = "CheckString";
		
		String thirdString = "CheckString";
		
		String secondString = new String("CheckString");
		
		String forthString = new String("checkstring");
		
		System.out.println(firstString == secondString);
		
		System.out.println(firstString == thirdString);
		
		System.out.println(firstString.equals(secondString));
		
		System.out.println(firstString.equals(forthString));
		
		System.out.println(firstString.equalsIgnoreCase(forthString)); 
		
		
		String onestring = "Test Java";
		String otherString = "Test Java";
		
		System.out.println(onestring.equalsIgnoreCase(otherString.trim()));
		
		System.out.println(onestring.replace("Test", "Python"));
		
		String replaceValue = onestring.replace("Test", "Python");
		System.out.println(replaceValue);
		
		String removeSpaces = "This is for test for space for in line ";
		
		System.out.println(removeSpaces.replace(" ", ""));
		
		System.out.println(removeSpaces.replaceAll(" ", ""));
		
		System.out.println(removeSpaces.replaceFirst(" ", ""));
		
		System.out.println(removeSpaces.replace("for", "other"));
		
		System.out.println(removeSpaces.replaceAll("for", "other"));
		
		//removeSpaces = removeSpaces.replace("for", "other");
		
		if(removeSpaces.contains("for")) {
			System.out.println("Present");
		}else {
			System.out.println("Not Present");
		}
		
		String yourName = "My Name is Sharda";
		
		System.out.println(yourName.replace("Sharda", "Sharada"));
		
		
		
		//Write a program to find the number of characters in below String
		//My Name is Vikas Vikas 
		
		String s11="My Name is Vikas Vikas Vikas";
		String s12="aaaggddrrffttbvffeewwkkiillyyuufffhhggsssbbvzzmmkk";
		char []ch=s11.toCharArray();
		
		for(int i = 0; i<ch.length; i++) {
			if(ch[i]== 'V') {
				System.out.println(ch[i]);
				System.out.println(i);
			}
		}
		
	}

}
