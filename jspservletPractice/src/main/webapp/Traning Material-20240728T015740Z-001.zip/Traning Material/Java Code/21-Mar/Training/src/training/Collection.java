package training;

import java.util.ArrayList;
import java.util.Iterator;

public class Collection {
	
	public static void main(String[] args) {
		ArrayList<String> nameList = new ArrayList<String>();
		ArrayList<String> classList = new ArrayList<String>();
		
		nameList.add("Vikas");
		nameList.add("John");
		nameList.add("Vikas");
		nameList.add("Tom");
		
		System.out.println("Size of the List " + nameList.size());
		
		//1
		Iterator<String> itr = nameList.iterator();
		while(itr.hasNext()) {
			System.out.println("Student name " + itr.next());
		}
		
		//For loop
		
		for(String name : nameList)
		{
			System.out.println(name);
		}
		
	}

}
