package strings;

public class ValidateInput {

	public static void main(String[] args) {
		String name = "Mr Vikas";
		
		String s1 = "My Name is MO";
		// OM si emaN yM
		
		System.out.println(name);
		
		//1.
		
		if(name.contains("Mr")) {
			System.out.println("Don't use Mr in name");
		}
		
		char []ch=name.toCharArray();
		
		for(int i = 0; i<ch.length; i++) {
			if(ch[i]== '1' || ch[i]== '2' || ch[i]== '3' || ch[i]== '4' || 
					ch[i]== '5' || ch[i]== '6' || ch[i]== '7' || ch[i]== '8' || 
					ch[i]== '9' || ch[i]== '0') {
				System.out.println("Number is not allowed in name");
				break;
			}
		}
	}
}
