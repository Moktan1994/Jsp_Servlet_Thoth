package training;

public class JavaIf {

	public static void main(String[] args) {
		int amount = 50;
		String name = "John";
		
		if(amount > 50 && name == "John" 
				&& name == "SAM") {
			System.out.println("Please give money to John");
		}
		else if(amount == 50 && name == "Sam") {
			System.out.println("Please give money to Sam");
		}
		else if(amount == 50 && name == "Sam") {
			System.out.println("Please give money to Sam");
		}
		else {
			System.out.println("Give money to other person");
		}
			

	}

}
