package training;

import java.util.Scanner;


public class Test1 {


 public static void main(String[] args) {


  Scanner S = new Scanner(System.in);
  
  int result = 0 ;
  int x = 0;
  int y = 0;
   
  System.out.print("Enter Operator Name: ");
  String OPERATOR = S.nextLine();
    menu();  
    
  while(true) {
  System.out.println("Select Operation");
  int op = S.nextInt();
   
  if(op == 6) {
   System.out.println("THANK YOU!!!");
   System.exit(0); 
  }
   
  if(op == 5) {
   menu();    
  }
             
  System.out.println("Enter First Number");
  x = S.nextInt();
   
  System.out.println("Enter Second Number");
   y = S.nextInt();
  
   
  if (op == 1) {
   result = sum(x, y);
  }
  
  else if(op == 2) {
   result = subtract(x, y);
  }
  
  else if(op == 3) {
   result = divide(x, y);
  }
  
  else if(op == 4) {
   result = multiply(x, y);
   }
   
  System.out.println("Result: " + result);
 
  System.out.println("Repeat Calculation......Y/N");  // only loop...... not exiting
  
  String Repeat = S.next().toLowerCase(); // Operator is not understanding 
  char input = Repeat.charAt(0);
  
  if (input == 'n') {
   System.out.println("Thank you!");
	  System.exit(0);
  }
  else if (input == 'y') {
   main(args);
  }
   }
    }
 
 
  public static void menu() {
   System.out.println("1. Sum of two number");
   System.out.println("2. Sub");
   System.out.println("3. Multiply");
   System.out.println("4. Division");
   System.out.println("5. Mainmenu");
   System.out.println("6. Exit");
  
  }


  public static int sum(int x, int y) {
   
   return (x + y);
  }
  
  public static int subtract(int x, int y) {
   
   return (x - y);
  }
  public static int divide(int x, int y) {
 
   return (x / y);
  }
  public static int multiply(int x, int y) {
 
   return (x * y);
  }
}
