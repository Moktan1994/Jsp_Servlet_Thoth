package training;

public class Operators {

	public static void main(String[] args) {
		
		int number1 = 10;
		System.out.println(number1);
		
		int number2 = 15;
		
		System.out.println(number2 > number1);
		
		String string1 = "Vikas";
		String string2 = "Mo";
		
		System.out.println(string1 == "Vikas" || string2 == "Sharada");
		
		//if(string1 == "Vikas" && string) {
			
		//}

	}

}
