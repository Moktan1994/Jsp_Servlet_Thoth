package collection;

import java.util.ArrayList;
import java.util.Collections;

public class AddStudentInfo {

	public static void main(String[] args) {
		
		ArrayList<Student> studentList = new ArrayList<Student>();
		
		//Object of the Class
		Student student = new Student();
		
		
		//1 
		//Refrence of class
		//student = new Student();
		
		student.setName("MO");
		student.setDateOfBirth("15-Mar-2000");
		student.setClassName(5);
		student.setCountryName("US");
		student.setIdValue(201);
		student.setFatherName("ABC");
		student.setMotherName("xyz");
		
		studentList.add(student);
		
		//2 
		
		student = new Student();
		
		student.setName("ELAHA");
		student.setDateOfBirth("14-Mar-2001");
		student.setClassName(6);
		student.setCountryName("US");
		student.setIdValue(101);
		student.setFatherName("ABC");
		student.setMotherName("xyz");
		
		studentList.add(student);
		System.out.println(student);
		
		//Show student value
		//showStudentInfo(studentList);
		
		//2 
		
		//System.out.println("New Student Joined");
		
		student = new Student();
		
		student.setName("Vikas");
		student.setDateOfBirth("14-Mar-2002");
		student.setClassName(7);
		student.setCountryName("India");
		student.setIdValue(102);
		student.setFatherName("ABC");
		student.setMotherName("xyz");
		
		studentList.add(student);
		
		System.out.println(student);
		
		//showStudentInfo(studentList);

	}
	
	private static void showStudentInfo(ArrayList<Student> studentList) {
		
		int count = 1;
		for(Student st : studentList) {
			System.out.print("S.No = " + count++);
			System.out.print(" , Name = " + st.getName());
			System.out.print(" , Date of Birth = " + st.getDateOfBirth());
			System.out.print(" , Class = " + st.getClassName());
			System.out.print(" , Country = " + st.getCountryName());
			System.out.println(" , IdValue = " + st.getIdValue());
			System.out.println(" , Father Name = " + st.getFatherName());
			System.out.println(" , Mother Name = " + st.getMotherName());
			
			System.out.println("------------------------");
		}
		
	}

}
