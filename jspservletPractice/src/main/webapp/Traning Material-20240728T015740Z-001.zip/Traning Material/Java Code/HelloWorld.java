package training; // Package

public class HelloWorld { // Class 
	
	public static void main(String[] args) { //Method
		System.out.println("Hello One");
		
		System.out.println("Hello Two");
		
		System.out.println("Hello All");
		
		printName();
		
		printNameAll();
		
	}
	
	public static void printName() { //Method
		System.out.println("Hello All Again");
	}
	
	public static void printNameAll() { //Method
		System.out.println("Hello All Team");
	}

}
