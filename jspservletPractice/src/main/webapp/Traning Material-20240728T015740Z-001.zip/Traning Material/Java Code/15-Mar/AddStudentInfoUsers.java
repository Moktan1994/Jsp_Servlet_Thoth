package collection;

import java.util.ArrayList;
import java.util.Scanner;

public class AddStudentInfoUsers {

	public static void main(String[] args) {
		
		ArrayList<Student> studentList = new ArrayList<Student>();
		
		//Object of the Class
		Student student = new Student();
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Your Name");
		student.setName(scanner.nextLine());

		System.out.println("Enter Your Date Of Birth");
		student.setDateOfBirth(scanner.nextLine());
		
		studentList.add(student);
		
		showStudentInfo(studentList);
		
		scanner.close();

	}
	
	private static void showStudentInfo(ArrayList<Student> studentList) {
		
		int count = 1;
		for(Student st : studentList) {
			System.out.print("S.No = " + count++);
			System.out.print(" , Name = " + st.getName());
			System.out.print(" , Date of Birth = " + st.getDateOfBirth());
			//System.out.print(" , Class = " + st.getClassName());
			//System.out.print(" , Country = " + st.getCountryName());
			//System.out.println(" , IdValue = " + st.getIdValue());
			//System.out.println(" , Father Name = " + st.getFatherName());
			//System.out.println(" , Mother Name = " + st.getMotherName());
			
			//System.out.println("------------------------");
		}
		
	}

}
