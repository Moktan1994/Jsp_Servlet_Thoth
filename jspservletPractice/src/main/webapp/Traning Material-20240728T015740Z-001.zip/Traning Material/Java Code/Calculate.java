package com.calculator;

import java.util.Scanner;

public class Calculate {
	
	//Public - Access Modifier
	//static - a way to call the methods
	//void - means this method doesn't returning anything
	//main - name of the method
	//String[] - use to get the inputs 
	public static void main(String[] args) {
		String name;
		int x=0, y=0, sum=0;
		//System.out.println(35+70);
		System.out.println("Enter you name");
		
		Scanner s = new Scanner(System.in);
		name = s.next();
		
		System.out.println("Hello " +name);
		
		System.out.println("");
		
		Scanner s1 = new Scanner(System.in);
		System.out.println("Type a number " );
		
		x = s1.nextInt();
		
		System.out.println("Type another number " );
		y = s1.nextInt();
		
		sum = x+y;
		
		System.out.println("Sum X and Y =" + sum);
		
	}

}
