package oops;

public class CallInterface extends AbstractClass implements FirstInterface, SecondInterface{

	public static void main(String[] args) {
		
		CallInterface ci = new CallInterface();
		
		ci.createEngine();
		ci.createHorn();
		ci.createBreak();
		ci.createSunRoof();
		
		ci.engine();

	}
	
	public void createEngineNew() {
		System.out.println("Engine");
	}
	
	public void createHorn() {
		System.out.println("Horn");
	}
	
	public void createBreak() {
		System.out.println("Breake");
	}
	
	public void createSunRoof() {
		System.out.println("Sunroof");
	}
	
	public void useMyNameOnEngine() {
		System.out.println("This engine is belongs to Abstract Class");
	}
	
	public void createEngine() {
		System.out.println("Engine created 30 HS power");
	}

}
