package oops;

public interface SecondInterface {
	
	public void createSunRoof();

}
