package oops;

abstract public class AbstractClass {
	
	public void engine() {
		System.out.println("20 HS Power engine");
	}
	
	public void useMyLogo() {
		System.out.println("This Engine belongs to AbstractClass");
	}
	
	public abstract void useMyNameOnEngine();
	
	public abstract void createEngine();

}
