package oops;

public interface FirstInterface {
	
	public void createEngineNew();
	
	public void createHorn();
	
	public void createBreak();

}
