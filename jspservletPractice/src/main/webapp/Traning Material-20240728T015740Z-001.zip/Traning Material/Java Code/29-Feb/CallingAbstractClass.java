package oops;

public class CallingAbstractClass extends AbstractClass{

	public static void main(String[] args) {
		
		CallingAbstractClass cac = new CallingAbstractClass();
		
		cac.createEngine();

	}
	
	public void useMyNameOnEngine() {
		System.out.println("This engine is belongs to Abstract Class");
	}
	
	public void createEngine() {
		System.out.println("Engine created 30 HS power");
	}

}
