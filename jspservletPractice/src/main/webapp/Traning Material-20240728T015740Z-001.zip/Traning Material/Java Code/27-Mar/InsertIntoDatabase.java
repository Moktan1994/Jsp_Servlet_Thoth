package database;

import java.sql.*;

public class InsertIntoDatabase {
	public static void main(String args[]) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			Connection con=DriverManager.getConnection(  
					"jdbc:mysql://localhost:3306/training","root","password");

			//PreparedStatement stmt = 
				//	con.prepareStatement("insert into student_details_tbl(name, age) values(?,?)");
			// 1 specifies the first parameter in the query
			//stmt.setString(1, "MO");
			//stmt.setInt(2, 20);
			
			PreparedStatement stmt = 
					con.prepareStatement("insert into student_details_tbl(name, age) values('Maryam',21)");

			int i = stmt.executeUpdate();
			System.out.println(i + " records inserted");

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
