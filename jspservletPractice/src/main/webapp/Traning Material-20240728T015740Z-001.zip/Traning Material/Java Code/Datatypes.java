package com.calculator;

public class Datatypes {

	public static void main(String[] args) {
		int numOne = 2147483647;
		float numFloat = 5.25f;
		char charValue = 'A';
		boolean booLean = false;
		String myText = "Hello in the java world";
		
		int myInt = 9;
	    double myDouble = myInt; 
	    
	    System.out.println(myInt);
	    System.out.println(myDouble);

		
		System.out.println(numOne);
		System.out.println(numFloat);
		System.out.println(charValue);
		System.out.println(booLean);
		System.out.println(myText);
	}

}
