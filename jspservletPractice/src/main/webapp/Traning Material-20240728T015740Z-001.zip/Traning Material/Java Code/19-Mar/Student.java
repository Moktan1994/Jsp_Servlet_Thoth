package collection;

public class Student {

	private String name;
	private String dateOfBirth;
	private Integer className;
	private String countryName;
	private Integer idValue;
	private String fatherName;
	private String motherName;

	public Student() {	
	}
	
	public Student(String name, String dateOfBirth, Integer className) {
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.className = className;
	}
	
	public Student(String name, String dateOfBirth, Integer className, String country) {
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.className = className;
		this.countryName = country;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Integer getClassName() {
		return className;
	}

	public void setClassName(Integer className) {
		this.className = className;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Integer getIdValue() {
		return idValue;
	}

	public void setIdValue(Integer idValue) {
		this.idValue = idValue;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

}
