package collection;

import java.util.ArrayList;

public class HashSet {

	public static void main(String[] args) {
		
		/*ArrayList<String> arrList = new ArrayList<String>();
		arrList.add("Mon");
		arrList.add("Tue");
		arrList.add("Wed");
		arrList.add("Mon");*/
		
		//System.out.println(arrList);
		
		java.util.HashSet<String> newSet = new java.util.HashSet<String>();
		
		newSet.add("Mon");
		newSet.add("Tue");
		newSet.add("Wed");
		newSet.add("Mon");
		
		System.out.println(newSet.size());
		
		System.out.println(newSet);

	}

}
