package com.calculator;

public class Operators {

	public static void main(String[] args) {
		int numValue = 15;
		
		//1,2,3,4,5,6
		
		int inputNumber = 10;
		
		System.out.println(++inputNumber);
		
		System.out.println(numValue);
		
		System.out.println(++numValue);
		
		System.out.println(numValue++);
		
		System.out.println(numValue);
		
		System.out.println(--numValue);
		
		numValue += 10;
		
		System.out.println(numValue);
		
		// Comparison
		
		int value1 = 10;
		int value2 = 20;
		
		System.out.println(value1 == value2 || value1 < value2);

	}

}
