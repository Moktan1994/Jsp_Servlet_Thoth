package training;

public class JavaSwitch {

	public static void main(String[] args) {
		int day = 10;
		
		switch(day)
		{
		case 1 :
			System.out.println("Sunday");
			break;
		case 2:
			System.out.println("Monday");
			break;
		case 3 :
			System.out.println("Tue");
			break;
		case 4:
			System.out.println("Wed");
			break;
		case 5 :
			System.out.println("Thrus");
			break;
		case 6:
			System.out.println("Friday");
			break;
		case 7:
			System.out.println("Sat");
			break;	
		default :
			System.out.println("Please enter value between 1 to 7");
			break;
		}

	}

}
