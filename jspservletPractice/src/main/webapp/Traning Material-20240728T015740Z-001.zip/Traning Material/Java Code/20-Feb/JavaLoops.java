package training;

public class JavaLoops {

	public static void main(String[] args) {
//While loop
		String name = "Sam";
		
		while(name == "Vikas") {
			System.out.println("Hello Vikas");
			break;
		}

// for loop
		for(int number = 1;number <=10;number++) {
			System.out.println(number);
		}
		
	}

}
