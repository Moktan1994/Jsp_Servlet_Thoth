package training;

public class JavaConditions {

	public static void main(String[] args) {
		
		int x = 18;
		int y = 20;
		
		
		if(x < y || x == y) 
		{
			System.out.println("Smaller or Equal");
		}
		
		if(x == y)
		{
			System.out.println("Equal");
		}
		
		if(x < y) 
		{
			System.out.println("Smaller");
		}else {
			System.out.println("Greater");
		}

	}

}
