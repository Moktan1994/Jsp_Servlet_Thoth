package oops;

public class AccessModifiers {
	
	private int age = 10;  // This is called only inside the class
	String name = "Vikas"; // This is accessible in same package only
	public String dob = "21-Sep-1987"; // This is accessible any where
	protected String address = "UK"; // This is accessible in same package or in sub classes (inhertance)

}
