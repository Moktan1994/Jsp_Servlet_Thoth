package oops;

public class Person2 {
	
	int age = 30;
	
	public void setAge(int age) {
		this.age = age;
		
		//System.out.println("Method inside " + age);
	}
	
	public static void main(String[] args) {
		Person2 p2 = new Person2();
		
		System.out.println(p2.age);
		
		p2.setAge(40);
		
		System.out.println(p2.age);
	}

}
