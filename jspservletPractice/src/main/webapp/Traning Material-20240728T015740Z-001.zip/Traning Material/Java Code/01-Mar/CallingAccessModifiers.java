package classes;

import oops.AccessModifiers;

public class CallingAccessModifiers extends AccessModifiers{

	public static void main(String[] args) {
		AccessModifiers am = new AccessModifiers();
		
		CallingAccessModifiers cam = new CallingAccessModifiers(); 
		
		System.out.println(am.dob);
		
		System.out.println(cam.address);
		
	}

}
