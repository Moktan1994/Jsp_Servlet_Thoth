package oops;

public class OtherPerson {

	public static void main(String[] args) {
		Person p = new Person();
		
		System.out.println(p.getAge());
		
		System.out.println(p.getAge());
		
		System.out.println(p.getName());
		
	}

}
