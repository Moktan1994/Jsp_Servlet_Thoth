package com.spring.training;

public class Address {
	
	public String name;
	public String city;
	
	public Address(String name, String city) {
		this.name = name;
		this.city = city;
	}

}
