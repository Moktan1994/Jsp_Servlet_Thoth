package com.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	
	@RequestMapping("/hello")
	public ModelAndView hellomvc() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		return mv;
	}
	
	@RequestMapping("/welcome")
	public ModelAndView welcomemvc() {
		ModelAndView mv;
		
		mv = new ModelAndView();
		int i=0;
		if(i==1)
			mv.setViewName("welcome");
		else if(i==0)
			mv.setViewName("index");
		else
			mv.setViewName("hello");
		return mv;
	}

}
