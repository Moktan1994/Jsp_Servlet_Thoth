package com.spring.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ShowStudentInformation {

	public static void main(String[] args) {
		ApplicationContext ctn = new ClassPathXmlApplicationContext("application_context_student.xml");

		Student student = (Student) ctn.getBean("student1");
		student.getStudentDetails();
		
		System.out.println(student.address.name);
		System.out.println(student.address.city);
	}

}
