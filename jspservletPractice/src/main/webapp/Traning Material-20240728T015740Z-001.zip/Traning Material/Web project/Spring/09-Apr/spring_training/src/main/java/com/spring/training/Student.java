package com.spring.training;

public class Student {

	public Address address;
	
	public Student() {
		
	}
	
	public Student(Address address) {
		System.out.println("Hitting Constructor");
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		System.out.println("Hitting setter method");
		this.address = address;
	}
	
	public void getStudentDetails() {
		System.out.println("Address of the Student "+ address.city);
	}

}
