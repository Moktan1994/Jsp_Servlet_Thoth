package com.rajeshkawali.util;

public class RecordNotFoundException extends Exception {

	public RecordNotFoundException() {

	}

	public RecordNotFoundException(String msg) {
		System.out.println(msg);
	}
}
