package com.rajeshkawali;
//https://www.javaguides.net/2020/05/spring-boot-crud-web-application-with-thymeleaf.html
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootApplication.class, args);
	}

}
