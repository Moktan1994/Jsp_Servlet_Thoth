package com.product.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class ProductExceptionController extends RuntimeException
{
	
	
	
}
