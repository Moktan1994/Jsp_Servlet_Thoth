package com.product.controller;

public class AccountController {
	
	public static void main(String[] args) {
		
	}

}
