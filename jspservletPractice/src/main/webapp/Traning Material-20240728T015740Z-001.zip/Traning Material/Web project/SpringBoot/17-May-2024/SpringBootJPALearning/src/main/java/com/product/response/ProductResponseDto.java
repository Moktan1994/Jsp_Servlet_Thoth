package com.product.response;

import com.product.entity.ProductEO;
import com.product.entity.ProductMasterEO;

public class ProductResponseDto {

	String responseCode;
	String responseMessage;
	ProductEO poProductEO;
	ProductMasterEO poMasterEO;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public ProductEO getPoProductEO() {
		return poProductEO;
	}

	public void setPoProductEO(ProductEO poProductEO) {
		this.poProductEO = poProductEO;
	}

	public ProductMasterEO getPoMasterEO() {
		return poMasterEO;
	}

	public void setPoMasterEO(ProductMasterEO poMasterEO) {
		this.poMasterEO = poMasterEO;
	}

}
