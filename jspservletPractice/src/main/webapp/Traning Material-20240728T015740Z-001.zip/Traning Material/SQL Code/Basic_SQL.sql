#Create Table 
# create table "TableName"

create table student_info_tbl
(
 name varchar(50),
 age int,
 dateofbirth varchar(20),
 country varchar(50)
);

#Insert data into the table

insert into student_info_tbl values ('Vikas',30,'12-Mar-2000','India');
insert into student_info_tbl values ('MO',25,'12-Mar-2001','US');

insert into student_info_tbl (name, age) values ('Vikas',30);

insert into student_info_tbl (name, age, dateofbirth, country) 
values ('Maryam',20,'24-Mar-2001','US');

#Check the data from Table

select * from student_info_tbl where name = 'Vikas';

#Update information
update student_info_tbl set country = 'US1' where name = 'Maryam';
update student_info_tbl set country = 'US2' where name = 'MO';
update student_info_tbl set country = 'US3' where name = 'Vikas';



